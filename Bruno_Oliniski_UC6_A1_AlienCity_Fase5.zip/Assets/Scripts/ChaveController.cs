﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChaveController : MonoBehaviour
{
    public bool chave1 = false;
    public bool chave2 = false;
    
    void Start() {
        
    }

    void Update()
    {
        
    }
    
   
}
